package jbq061.assignment3;

public interface Subscriber {
	void receiveNotification(String channelName, Object changedState);
}
