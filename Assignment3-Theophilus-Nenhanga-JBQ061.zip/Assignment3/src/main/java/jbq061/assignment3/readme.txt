Name: Theophilus Nyasha Nenhanga
Student Number: 11325753
NSID: JBQ061
Date: 2023/11/10

How To Run:
    * Run main method in EditorApp.java

What Works:
    * Part 1 - Completed - MVC basics implemented
    * Part 2 - Completed - User Interaction implemented
    * Part 3 -  Completed -  Publish subscribe and second view implemented
    * Part 4 - Partially completed -
        - The guide does not appear when you long press control on its own.
        - However if you long press control and a command the guide will appear.
        - The guide image can be found in the resources folder.